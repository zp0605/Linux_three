#ifndef _SOUND_H_
#define _SOUND_H_

void oss_levels(struct ng_audio_buf *buf, int *left, int *right);

#endif /* _SOUND_H_ */
