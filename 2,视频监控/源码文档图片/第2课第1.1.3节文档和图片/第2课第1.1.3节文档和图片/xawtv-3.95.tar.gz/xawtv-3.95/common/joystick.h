int joystick_tv_init(char *dev);
void joystick_tv_havedata(int js);
