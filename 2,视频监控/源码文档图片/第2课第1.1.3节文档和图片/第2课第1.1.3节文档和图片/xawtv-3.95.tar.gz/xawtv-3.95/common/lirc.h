int lirc_tv_init(void);
int lirc_tv_havedata(void);
