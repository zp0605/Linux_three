extern void vbi_tty(char *device, int debug, int sim);
