char           *tilde_expand(char *);
void            CompleteAction(Widget, XEvent *, String *, Cardinal *);
