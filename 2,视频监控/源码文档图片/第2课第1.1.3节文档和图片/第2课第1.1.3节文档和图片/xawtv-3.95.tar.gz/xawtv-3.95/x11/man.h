void man(char *page);
void man_cb(Widget widget, XtPointer clientdata, XtPointer call_data);
void man_action(Widget widget, XEvent *event,
		String *params, Cardinal *num_params);
