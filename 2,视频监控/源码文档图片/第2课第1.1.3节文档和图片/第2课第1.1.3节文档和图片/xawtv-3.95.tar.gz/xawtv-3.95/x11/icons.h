void x11_icons_init(Display *dpy, unsigned long bg);
