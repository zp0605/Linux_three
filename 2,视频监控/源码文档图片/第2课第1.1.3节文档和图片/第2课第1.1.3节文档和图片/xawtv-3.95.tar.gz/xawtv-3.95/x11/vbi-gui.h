void vbi_create_widgets(Widget shell, struct vbi_state *vbi);
