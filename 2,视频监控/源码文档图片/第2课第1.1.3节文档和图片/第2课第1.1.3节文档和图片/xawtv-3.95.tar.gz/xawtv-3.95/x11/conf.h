extern void create_confwin(void);
extern void conf_station_switched(void);
extern void conf_list_update(void);
